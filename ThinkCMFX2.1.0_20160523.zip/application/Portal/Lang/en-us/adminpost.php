<?php
return array(
    "TITLE" => "Title",
    "CATEGORY" => 'Category',
    "HITS" => 'Hits',
    "KEYWORDS" => 'Keywords',
    "COMMENT_COUNT" => 'Comments',
    "SOURCE" => 'Source',
    "ABSTRACT" => 'Abstract',
    "THUMBNAIL" => "Thumbnail",
    "AUTHOR" => 'Author',
    "PUBLISH_DATE" => 'Date'
);