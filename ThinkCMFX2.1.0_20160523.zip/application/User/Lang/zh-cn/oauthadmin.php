<?php
return array(
		"USERNAME" => '用户名',
		"USER_FROM" => '来源',
		"AVATAR" => '头像',
		"BINGDING_ACCOUNT" => '绑定账号',
		"FIRST_LOGIN_TIME" => '首次登录时间',
		"LAST_LOGIN_TIME" => "最后登录时间",
		"LAST_LOGIN_IP" => '最后登录IP',
		"LOGIN_TIMES" => '登录次数',
		"STATUS" => '状态',
		"ACTIONS" => "操作",
		
);