<?php
return array(
		"SENDER_NAME" => '发件人',
		"SENDER_EMAIL_ADDRESS" => '邮箱地址',
		"SENDER_SMTP_SERVER" => 'SMTP服务器',
		"SMTP_MAIL_ADDRESS" => '发件箱帐号',
		"SMTP_MAIL_PASSWORD" => '发件箱密码',
		"EMAIL_ACTIVATION" => '邮箱激活',
		"EMAIL_SUBJECT" => '邮件标题',
		"EMAIL_TEMPLATE" => '邮件模版',
		"EMAIL_TEMPLATE_HELP_TEXT" =>'请用{$link}代替激活链接，{$username}代替用户名'
		
);